-- ///////////////////////////////////////////////////////////
-- // PROJECTOR                                             //
-- //-------------------------------------------------------//
-- // Version : 8.3.4                                       //
-- // Date : 2020-02-17                                     //
-- ///////////////////////////////////////////////////////////
-- Patch on V8.3.0


INSERT INTO `${prefix}linkable` ( `name`, `idle`) VALUES 
('ChangeRequest', 0);

INSERT INTO `${prefix}copyable` ( `name`, `idle`) VALUES
('ChangeRequest', 0);

INSERT INTO `${prefix}notifiable` ( `name`, `idle`) VALUES
('ChangeRequest', 0);
-- ///////////////////////////////////////////////////////////
-- // PROJECTOR                                             //
-- //-------------------------------------------------------//
-- // Version : V3.3.1                                      //
-- // Date : 2013-04-29                                     //
-- // Note : specific for linux envs                        //
-- //        (where table name is case sensitive)           //
-- ///////////////////////////////////////////////////////////
--
--

RENAME TABLE `${prefix}todayParameter` to `${prefix}todayparameter`;
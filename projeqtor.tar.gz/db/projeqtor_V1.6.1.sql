
-- ///////////////////////////////////////////////////////////
-- // PROJECTOR                                             //
-- //-------------------------------------------------------//
-- // Version : V1.6.1                                      //
-- // Date : 2010-07-21                                     //
-- ///////////////////////////////////////////////////////////
--
--

RENAME TABLE `${prefix}expenseDetail` to `${prefix}expensedetail`;

RENAME TABLE `${prefix}expenseDetailType` to `${prefix}expensedetailtype`;
 

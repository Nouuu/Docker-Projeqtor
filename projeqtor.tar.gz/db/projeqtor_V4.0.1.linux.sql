-- ///////////////////////////////////////////////////////////
-- // PROJECTOR                                             //
-- //-------------------------------------------------------//
-- // Version : 4.0.1                                       //
-- // Date : 2013-11-04                                     //
-- // Note : specific for linux envs                        //
-- //        (where table name is case sensitive)           //
-- ///////////////////////////////////////////////////////////
--
--

RENAME TABLE `${prefix}overallProgress` to `${prefix}overallprogress`;